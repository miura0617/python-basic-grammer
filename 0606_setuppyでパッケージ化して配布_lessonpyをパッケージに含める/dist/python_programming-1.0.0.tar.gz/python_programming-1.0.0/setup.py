from distutils.core import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://life-style-blog.com',
    license='Free',
    author='jmiura',
    author_email='',
    description='Sample package'
)
