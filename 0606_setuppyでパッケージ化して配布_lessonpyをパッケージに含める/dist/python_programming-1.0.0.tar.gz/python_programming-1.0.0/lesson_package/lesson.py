from talk import human

# r = lesson_package.utils.say_twice('hello')

print(human.sing())
print(human.cry())